from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.urls import reverse_lazy
from django.http import HttpResponseForbidden
from .models import Salon, Service,Appointment
from django.contrib.auth import login
from .forms import CustomUserCreationForm, SalonOwnerCreationForm,ServiceForm


from .forms import AppointmentForm
from django.contrib.auth.views import (
    PasswordResetView, PasswordResetDoneView,
    PasswordResetConfirmView, PasswordResetCompleteView
)


from .models import Salon

# 🔐 Login / Logout
# def login_view(request):
#     error = ''
#     if request.method == 'POST':
#         email = request.POST.get('email')
#         password = request.POST.get('password')
#         user = authenticate(request, username=email, password=password)
#         if user:
#             login(request, user)
#             # 🚦 Redirect based on role
#             if user.role == 'customer':
#                 return redirect('customer_dashboard')
#             elif user.role == 'salon_owner':
#                 return redirect('owner_dashboard')
#             elif user.role == 'admin' or user.is_superuser:
#                 return redirect('admin_dashboard')
#             else:
#                 return redirect('index')
#         error = 'Invalid email or password'
#     return render(request, 'login.html', {'error': error})


from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.contrib import messages

def login_view(request):
    error = ''
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        user = authenticate(request, username=email, password=password)

        if user:
            # 🔒 Block unverified users
            if not getattr(user, "is_verified", False):
                error = '⚠️ Please verify your email before logging in.'
                print(f"[DEBUG] Login blocked: {user.email} is_verified={user.is_verified}")
                return render(request, 'login.html', {'error': error})

            # ✅ Verified users can log in
            login(request, user)
            print(f"[DEBUG] Login success: {user.email} is_verified={user.is_verified}")

            # 🚦 Redirect based on role
            if user.role == 'customer':
                return redirect('customer_dashboard')
            elif user.role == 'salon_owner':
                return redirect('owner_dashboard')
            elif user.role == 'admin' or user.is_superuser:
                return redirect('admin_dashboard')
            else:
                return redirect('index')

        error = '❌ Invalid email or password'
        print(f"[DEBUG] Login failed: email={email}")

    return render(request, 'login.html', {'error': error})

def logout_view(request):
    logout(request)
    return redirect('login')


def register_view(request):
    if request.method == 'POST':
        user_form = CustomUserCreationForm(request.POST, request.FILES)  # Add request.FILES
        salon_form = SalonOwnerCreationForm(request.POST, request.FILES)  # Add request.FILES
        
        if user_form.is_valid():
            user = user_form.save(commit=False)
            user.is_approved = False
            user.username = user.email
            
            # Handle ID card upload for salon owners
            if user.role == 'salon_owner' and 'id_card' in request.FILES:
                user.id_card = request.FILES['id_card']
            
            user.save()
  
            if user.role == 'salon_owner' and salon_form.is_valid():
                salon = salon_form.save(commit=False)
                salon.owner = user
                
                # Handle salon image upload
                if 'salon_image' in request.FILES:
                    salon.salon_image = request.FILES['salon_image']
                
                salon.save()
                 # 🔑 Send OTP to email
          # inside register_view
            send_otp_via_email(user.email)

# store email in session
            request.session['pending_email'] = user.email  

            return redirect("verify-email")
            # return redirect('login')
    else:
        user_form = CustomUserCreationForm()
        salon_form = SalonOwnerCreationForm()
    
    return render(request, 'register.html', {
        'user_form': user_form,
        'salon_form': salon_form
    })

@login_required
def customer_dashboard(request):
    if request.user.role != 'customer':
        return HttpResponseForbidden("Not authorized.")
    
    # Get location filter from request
    location_filter = request.GET.get('location', '')
    
    # Get all approved salons, filtered by location if specified
    if location_filter:
        salons = Salon.objects.filter(approved=True, location__icontains=location_filter)
    else:
        salons = Salon.objects.filter(approved=True)
    
    # Get user's appointments
    appointments = Appointment.objects.filter(customer=request.user).order_by('-date', '-time')

    # Get unique locations for the filter dropdown
    unique_locations = Salon.objects.filter(approved=True).values_list('location', flat=True).distinct()

    return render(request, 'customer_dashboard.html', {
        'salons': salons,
        'appointments': appointments,
        'locations': unique_locations,
        'selected_location': location_filter
    })
@login_required
def cancel_appointment(request, appointment_id):
    appointment = get_object_or_404(Appointment, id=appointment_id, customer=request.user)
    appointment.delete()
    messages.warning(request, "Your appointment was cancelled.")
    return redirect('customer_dashboard')


# 🔍 Salon detail page
# @login_required
# def salon_detail(request, salon_id):
#     salon = get_object_or_404(Salon, id=salon_id, approved=True)
#     services = Service.objects.filter(salon=salon)
#     return render(request, 'salon_detail.html', {'salon': salon, 'services': services})

@login_required
def owner_dashboard(request):
    if request.user.role != 'salon_owner':
        return HttpResponseForbidden("Not authorized.")

    # Get the salon owned by this user
    salon = Salon.objects.filter(owner=request.user).first()

    if not salon:
        return render(request, 'owner_dashboard.html', {
            "salon": None,
            "services": [],
            "appointments": []
        })

    # Get all services offered by this salon
    services = Service.objects.filter(salon=salon)

    # Get all appointments for this salon
    appointments = Appointment.objects.filter(salon=salon).order_by('-date', '-time')

    return render(request, 'owner_dashboard.html', {
        "salon": salon,
        "services": services,
        "appointments": appointments,
        "owner": request.user
    })
@login_required
def delete_service(request, service_id):
    service = get_object_or_404(Service, id=service_id, salon__owner=request.user)
    service.delete()
    messages.success(request, "Service removed successfully.")
    return redirect('owner_dashboard')


# 🏠 Admin Dashboard → Already exists
@login_required
def admin_dashboard(request):
    if not request.user.is_superuser and getattr(request.user, 'role', '') != 'admin':
        return HttpResponseForbidden("You are not authorized to access this page.")
    salons = Salon.objects.all().order_by('-approved')
    return render(request, 'admin_dashboard.html', {'salons': salons})

@login_required
def approve_salon(request, salon_id):
    salon = get_object_or_404(Salon, id=salon_id)
    salon.approved = True
    salon.save()
    messages.success(request, f"{salon.name} approved.")
    return redirect('admin_dashboard')

@login_required
def reject_salon(request, salon_id):
    salon = get_object_or_404(Salon, id=salon_id)
    salon.approved = False
    salon.save()
    messages.warning(request, f"{salon.name} rejected.")
    return redirect('admin_dashboard')

# ✉️ Password Reset Flow
class MyPasswordResetView(PasswordResetView):
    template_name = 'registration/password_reset_form.html'
    email_template_name = 'registration/password_reset_email.html'
    success_url = reverse_lazy('password_reset_done')

class MyPasswordResetDoneView(PasswordResetDoneView):
    template_name = 'registration/password_reset_done.html'

class MyPasswordResetConfirmView(PasswordResetConfirmView):
    template_name = 'registration/password_reset_confirm.html'
    success_url = reverse_lazy('password_reset_complete')

class MyPasswordResetCompleteView(PasswordResetCompleteView):
    template_name = 'registration/password_reset_complete.html'

@login_required
def book_appointment(request, salon_id, service_id):
    salon = get_object_or_404(Salon, id=salon_id, approved=True)
    service = get_object_or_404(Service, id=service_id, salon=salon)

    if request.method == 'POST':
        form = AppointmentForm(request.POST)
        if form.is_valid():
            appointment = form.save(commit=False)
            appointment.customer = request.user
            appointment.salon = salon
            appointment.service = service
            appointment.status = 'pending'
            appointment.save()
            messages.success(request, "Your appointment has been booked!")
            return redirect('customer_dashboard')
    else:
        form = AppointmentForm()

    return render(request, 'book_appointment.html', {
        'form': form,
        'salon': salon,
        'service': service
    })

@login_required
def approve_booking(request, booking_id):
    booking = get_object_or_404(Appointment, id=booking_id, salon__owner=request.user)
    booking.status = "Approved"
    booking.save()
    return redirect('owner_dashboard')

@login_required
def disapprove_booking(request, booking_id):
    booking = get_object_or_404(Appointment, id=booking_id, salon__owner=request.user)
    booking.status = "Disapproved"
    booking.save()
    return redirect('owner_dashboard')

@login_required
def delete_booking(request, booking_id):
    booking = get_object_or_404(Appointment, id=booking_id, salon__owner=request.user)
    booking.delete()
    return redirect('owner_dashboard')


from.models import Category
@login_required
def add_service(request):
    if request.user.role != 'salon_owner':
        return HttpResponseForbidden("Not authorized.")
    
    salon = get_object_or_404(Salon, owner=request.user)
    categories = Category.objects.all()
    
    if request.method == 'POST':
        name = request.POST.get('name')
        category_id = request.POST.get('category')
        description = request.POST.get('description')
        price = request.POST.get('price')
        
        service = Service(
            salon=salon,
            name=name,
            description=description,
            price=price
        )
        
        if category_id:
            category = get_object_or_404(Category, id=category_id)
            service.category = category
        
        if 'service_image' in request.FILES:
            service.service_image = request.FILES['service_image']
        
        service.save()
        messages.success(request, "Service added successfully.")
        return redirect('owner_dashboard')
    
    return render(request, 'add_service.html', {'categories': categories})

@login_required
def edit_service(request, service_id):
    if request.user.role != 'salon_owner':
        return HttpResponseForbidden("Not authorized.")
    
    service = get_object_or_404(Service, id=service_id, salon__owner=request.user)
    categories = Category.objects.all()
    
    if request.method == 'POST':
        service.name = request.POST.get('name')
        category_id = request.POST.get('category')
        service.description = request.POST.get('description')
        service.price = request.POST.get('price')
        
        if category_id:
            category = get_object_or_404(Category, id=category_id)
            service.category = category
        else:
            service.category = None
        
        if 'service_image' in request.FILES:
            service.service_image = request.FILES['service_image']
        
        service.save()
        messages.success(request, "Service updated successfully.")
        return redirect('owner_dashboard')
    
    return render(request, 'edit_service.html', {
        'service': service,
        'categories': categories
    })


# views.pyfrom django.shortcuts import render, redirectfrom django.shortcuts import render, redirect
from django.contrib import messages
from .email import send_otp_via_email
from .models import CustomUser

def verify_email_view(request):
    if request.method == "POST":
        otp = request.POST.get("otp")
        email = request.session.get("pending_email")  # get email from session

        if not email:
            messages.error(request, "Session expired. Please register again.")
            return redirect("register")

        try:
            user = CustomUser.objects.get(email=email, otp=otp)

            # update verification status
            user.is_verified = True
            user.otp = None
            user.save()

            print(f"[DEBUG] User {user.email} verified → is_verified={user.is_verified}")

            # clear session after success
            if "pending_email" in request.session:
                del request.session["pending_email"]

            if user.is_verified:
                messages.success(request, "🎉 You are verified! Account created successfully.")
            else:
                messages.error(request, "⚠️ Verification failed, please try again.")

            return redirect("login")

        except CustomUser.DoesNotExist:
            print(f"[DEBUG] OTP verification failed for email={email}, otp={otp}")
            messages.error(request, "❌ Invalid OTP. Try again.")
            return redirect("verify-email")

    return render(request, "verify_email.html")
# views.py
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Salon, Feedback
from .forms import FeedbackForm
@login_required
def salon_detail(request, salon_id):
    salon = get_object_or_404(Salon, id=salon_id)
    
    # Use default reverse relation
    services = salon.service_set.all()
    
    feedbacks = salon.feedbacks.all().order_by("-created_at")

    # Handle feedback form
    if request.method == "POST":
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback = form.save(commit=False)
            feedback.customer = request.user
            feedback.salon = salon
            feedback.save()
            messages.success(request, "✅ Feedback added successfully!")
            return redirect("salon_detail", salon_id=salon.id)
    else:
        form = FeedbackForm()

    return render(request, "salon_detail.html", {
        "salon": salon,
        "services": services,
        "feedbacks": feedbacks,
        "form": form
    })


@login_required
def delete_feedback(request, feedback_id):
    feedback = get_object_or_404(Feedback, id=feedback_id)
    if feedback.customer == request.user:  # only owner can delete
        feedback.delete()
        messages.success(request, "🗑️ Your feedback was deleted successfully.")
    else:
        messages.error(request, "❌ You cannot delete someone else's feedback.")
    return redirect("salon_detail", salon_id=feedback.salon.id)


from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import render
from .models import Feedback, Salon

# Only allow admin users
def admin_required(user):
    return user.is_authenticated and user.role == 'admin'

@login_required
@user_passes_test(admin_required)
def low_feedback_dashboard(request):
    # Get only feedback with rating 1 or 2
    feedbacks = Feedback.objects.filter(rating__lte=2).order_by('-created_at')
    return render(request, "low_feedback_dashboard.html", {
        "feedbacks": feedbacks
    })