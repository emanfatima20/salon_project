# from django.urls import path
# from . import views
# from django.conf import settings
# from django.conf.urls.static import static
# urlpatterns = [
#     path('', views.login_view, name='login'),
#     # Authentication
#     path('login/', views.login_view, name='login'),
#     path('logout/', views.logout_view, name='logout'),
#     path('register/', views.register_view, name='register'),

#     # Role-based Dashboards
#     path('dashboard/admin/', views.admin_dashboard, name='admin_dashboard'),
#     path('dashboard/salon/', views.owner_dashboard, name='owner_dashboard'),
#     path('dashboard/customer/', views.customer_dashboard, name='customer_dashboard'),
#     path('salon/<int:salon_id>/', views.salon_detail, name='salon_detail'),
#     # Admin actions on salons
#     path('dashboard/admin/approve/<int:salon_id>/', views.approve_salon, name='approve_salon'),
#     path('dashboard/admin/reject/<int:salon_id>/', views.reject_salon, name='reject_salon'),

#     # Password reset
#     path('reset-password/', views.MyPasswordResetView.as_view(), name='password_reset'),
#     path('reset-password/done/', views.MyPasswordResetDoneView.as_view(), name='password_reset_done'),
#     path('reset/<uidb64>/<token>/', views.MyPasswordResetConfirmView.as_view(), name='password_reset_confirm'),
#     path('reset/done/', views.MyPasswordResetCompleteView.as_view(), name='password_reset_complete'),
#     path('salon/<int:salon_id>/<int:service_id>/book/', views.book_appointment, name='book_appointment'),
# path('appointment/cancel/<int:appointment_id>/', views.cancel_appointment, name='cancel_appointment'),
# path('booking/<int:booking_id>/approve/', views.approve_booking, name='approve_booking'),
# path('booking/<int:booking_id>/disapprove/', views.disapprove_booking, name='disapprove_booking'),
# path('booking/<int:booking_id>/delete/', views.delete_booking, name='delete_booking'),
#   path('delete-service/<int:service_id>/', views.delete_service, name='delete_service'),
# ]
# if settings.DEBUG:
#     urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.login_view, name='login'),
    # Authentication
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register_view, name='register'),

    # Role-based Dashboards
    path('dashboard/admin/', views.admin_dashboard, name='admin_dashboard'),
    path('dashboard/salon/', views.owner_dashboard, name='owner_dashboard'),
    path('dashboard/customer/', views.customer_dashboard, name='customer_dashboard'),
    path('salon/<int:salon_id>/', views.salon_detail, name='salon_detail'),
    
    # Admin actions on salons
    path('dashboard/admin/approve/<int:salon_id>/', views.approve_salon, name='approve_salon'),
    path('dashboard/admin/reject/<int:salon_id>/', views.reject_salon, name='reject_salon'),

    # Password reset
    path('reset-password/', views.MyPasswordResetView.as_view(), name='password_reset'),
    path('reset-password/done/', views.MyPasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', views.MyPasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset/done/', views.MyPasswordResetCompleteView.as_view(), name='password_reset_complete'),
    
    # Appointments
    path('salon/<int:salon_id>/<int:service_id>/book/', views.book_appointment, name='book_appointment'),
    path('appointment/cancel/<int:appointment_id>/', views.cancel_appointment, name='cancel_appointment'),
    path('booking/<int:booking_id>/approve/', views.approve_booking, name='approve_booking'),
    path('booking/<int:booking_id>/disapprove/', views.disapprove_booking, name='disapprove_booking'),
    path('booking/<int:booking_id>/delete/', views.delete_booking, name='delete_booking'),
    
    # Services
    path('delete-service/<int:service_id>/', views.delete_service, name='delete_service'),
    path('add-service/', views.add_service, name='add_service'),  # Add this line
    path('edit-service/<int:service_id>/', views.edit_service, name='edit_service'),  # Add this line
    path("verify-email/", views.verify_email_view, name="verify-email"),
      path("feedback/<int:feedback_id>/delete/", views.delete_feedback, name="delete_feedback"),

  path('/admin/low-feedback/', views.low_feedback_dashboard, name='low_feedback_dashboard'),
]



if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)