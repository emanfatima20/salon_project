from django.contrib import admin
from django.utils.html import format_html
from .models import CustomUser, Salon, Category, Service, Appointment ,Feedback


@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('customer', 'salon', 'rating', 'created_at')
    list_filter = ('rating', 'created_at')
    search_fields = ('customer__email', 'salon__name', 'comment')


@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = (
        'email', 'first_name', 'last_name', 'role',
        'is_approved', 'is_verified', 'otp',
        'display_id_card', 'date_joined'
    )
    list_filter = ('role', 'is_approved', 'is_verified', 'date_joined')
    search_fields = ('email', 'first_name', 'last_name', 'otp')
    readonly_fields = ('date_joined', 'last_login')

    fieldsets = (
        (None, {
            'fields': ('email', 'first_name', 'last_name')
        }),
        ('Authentication', {
            'fields': ('password',)
        }),
        ('Permissions', {
            'fields': ('role', 'is_approved', 'is_active', 'is_staff', 'is_superuser')
        }),
        ('Email Verification', {
            'fields': ('is_verified', 'otp')  # ✅ show verification fields in admin
        }),
        ('Important dates', {
            'fields': ('last_login', 'date_joined')
        }),
        ('ID Card', {
            'fields': ('id_card',)
        }),
    )

    def display_id_card(self, obj):
        if obj.id_card:
            return format_html('<a href="{}" target="_blank">View ID Card</a>', obj.id_card.url)
        return "No ID Card"
    display_id_card.short_description = 'ID Card'

# Salon Admin
@admin.register(Salon)
class SalonAdmin(admin.ModelAdmin):
    list_display = ('name', 'owner_email', 'location', 'contact_info', 'approved', 'display_salon_image')
    list_filter = ('approved',)
    search_fields = ('name', 'owner__email', 'location')
    readonly_fields = ('display_salon_image_detail',)
    
    def owner_email(self, obj):
        return obj.owner.email
    owner_email.short_description = 'Owner Email'
    
    def display_salon_image(self, obj):
        if obj.salon_image:
            return format_html('<img src="{}" style="max-height: 50px; max-width: 50px;" />', obj.salon_image.url)
        return "No Image"
    display_salon_image.short_description = 'Salon Image'
    
    def display_salon_image_detail(self, obj):
        if obj.salon_image:
            return format_html('<img src="{}" style="max-height: 300px; max-width: 100%;" />', obj.salon_image.url)
        return "No Image"
    display_salon_image_detail.short_description = 'Salon Image Preview'

# Category Admin
@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ('name',)

# Service Admin
@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ('name', 'salon_name', 'price', 'display_service_image')
    list_filter = ('salon',)
    search_fields = ('name', 'salon__name', 'description')
    readonly_fields = ('display_service_image_detail',)
    
    def salon_name(self, obj):
        return obj.salon.name
    salon_name.short_description = 'Salon'
    
    def display_service_image(self, obj):
        if obj.service_image:
            return format_html('<img src="{}" style="max-height: 50px; max-width: 50px;" />', obj.service_image.url)
        return "No Image"
    display_service_image.short_description = 'Service Image'
    
    def display_service_image_detail(self, obj):
        if obj.service_image:
            return format_html('<img src="{}" style="max-height: 300px; max-width: 100%;" />', obj.service_image.url)
        return "No Image"
    display_service_image_detail.short_description = 'Service Image Preview'

# Appointment Admin
@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('customer_email', 'salon_name', 'service_name', 'date', 'time', 'status', 'created_at')
    list_filter = ('status', 'date', 'salon')
    search_fields = ('customer__email', 'salon__name', 'service__name')
    readonly_fields = ('created_at',)
    
    def customer_email(self, obj):
        return obj.customer.email
    customer_email.short_description = 'Customer'
    
    def salon_name(self, obj):
        return obj.salon.name
    salon_name.short_description = 'Salon'
    
    def service_name(self, obj):
        return obj.service.name
    service_name.short_description = 'Service'