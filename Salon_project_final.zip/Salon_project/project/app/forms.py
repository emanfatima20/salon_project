from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import CustomUser, Salon, Service

class CustomUserCreationForm(UserCreationForm):
# In your form
    role = forms.ChoiceField(choices=[('customer','Customer'), ('salon_owner','Salon Owner')])

    id_card = forms.ImageField(required=False)  # Add this field
    
    class Meta:
        model = CustomUser
        fields = ('email', 'first_name', 'last_name', 'role', 'password1', 'password2', 'id_card')

class SalonOwnerCreationForm(forms.ModelForm):
    salon_image = forms.ImageField(required=False)  # Add this field
    
    class Meta:
        model = Salon
        fields = ('name', 'location', 'contact_info', 'salon_image')

from .models import Service

class ServiceForm(forms.ModelForm):
    class Meta:
        model = Service
        fields = ('name', 'category', 'description', 'price', 'service_image')
        
from .models import Appointment        
class AppointmentForm(forms.ModelForm):
    class Meta:
        model = Appointment
        fields = ('service', 'date', 'time')

        # forms.py
from django import forms
from .models import Feedback

class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ["rating", "comment"]
        widgets = {
            "rating": forms.Select(attrs={"class": "form-control"}),
            "comment": forms.Textarea(attrs={"rows": 3, "class": "form-control", "placeholder": "Write your feedback..."}),
        }
