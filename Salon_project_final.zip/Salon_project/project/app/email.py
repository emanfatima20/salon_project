# emails.py
import random
from django.core.mail import send_mail
from django.conf import settings
from .models import CustomUser

def send_otp_via_email(user_email):
    try:
        user = CustomUser.objects.get(email=user_email)
    except CustomUser.DoesNotExist:
        return None

    otp = str(random.randint(100000, 999999))  # 6-digit OTP
    user.otp = otp
    user.save()

    subject = "Your SalonApp OTP Verification Code"
    message = f"Dear {user.first_name},\n\nYour OTP code is {otp}.\n\nUse this to verify your account."
    email_from = settings.EMAIL_HOST_USER
    send_mail(subject, message, email_from, [user_email])
    print(otp)
    return otp
